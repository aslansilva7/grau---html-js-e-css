<script>
  function changeColor(element) {
      document.querySelectorAll('.nav-link').forEach(link => {
          link.classList.remove('active');
      });

      element.classList.add('active');
  }
  function showLoginModal() {
      document.getElementById('loginModal').style.display = 'block';
  }

  function closeLoginModal() {
      document.getElementById('loginModal').style.display = 'none';
  }

  // Funções simuladas de login
  function login() {
      alert('Simulação de Login');
      closeLoginModal();
  }

  function loginRaava() {
      alert('Simulação de Login Raava');
      closeLoginModal();
  }
</script>